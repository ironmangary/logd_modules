<?php
require_once("lib/http.php");

/*
EGW Inventory Core
Version 1.0 Beta (2020-07.12)
by Gary M. Hartzell
*/

function inv_getmoduleinfo(){
	$info = array(
		"name"=>"EGW Inventory Core",
		"version"=>"1.0 Beta",
		"author"=>"Gary Hartzell", 
		"override_forced_nav"=>true,
		"category"=>"Inventory",
		"download"=>"",
	"settings"=>array(
		"Inventory - General Settings,title",
		"max_amount"=>"Maximum number of items allowed per player (0 = unlimited):,int|0",
		"max_weight"=>"Maximum weight in items a player may have (0 = unlimited):,int|0",
),
	"prefs"=>array(
		"items"=>"How many items does user have?,int|0",
		"weight"=>"What is the weight of user's current inventory?,int|0",
),
);
	return $info;
	}

function inv_install(){
	module_addhook("village");
	module_addhook("forest");
	module_addhook("castle_greathall");
	return true;
}

function inv_uninstall(){
	return true;
}

function inv_dohook($hookname, $args){
	global $session;
	
switch($hookname){
		case "village":
			addnav("Inventory");
			addnav("Open your backpack","runmodule.php?module=inv");
		break;
		case "forest":
			addnav("Inventory");
			addnav("Open your backpack","runmodule.php?module=inv");
		break;
		case "castle_greathall":
			set_module_pref('where','greathall','custom');
			addnav("Inventory");
			addnav("Open your backpack","runmodule.php?module=inv");
		break;
	}
	return $args;
}

function inv_run() {

	global $session;
	page_header("Inventory");
	rawoutput("<center><h2>Your Inventory</h2></center><br>");

	$op = httpget('op');
	switch ($op) {
		case "":
			$texts=array();
			require_once("lib/egw.php");
			egw_nav();
			if (get_module_pref("items") <= 0) {
				output("You open your backpack and look inside.  It is completely empty!");
			} else {
				output("You open your backpack and take a look inside.  You have the following inventory:`n`n");

				modulehook("inv_list",$texts);

				output("`nYou have a total of %s items, weighing a total of %s ounces.", get_module_pref("items"), get_module_pref("weight"));
		break;
	}
}

	page_footer();
}
?>

