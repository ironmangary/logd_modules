
<?php

/*
The In-and-Out
for Earth Gone Wrong
Version 1.1 (12/31/22)
by Gary M. Hartzell

A convenience/general store to sell inventory items.

Version History
v1.1 (12/31/22) - Added customization settings, adapted to work with EGW travel system
v1.0 (08/20/20) - Initial release
*/

function inout_getmoduleinfo(){
	$info = array(
		"name"=>"The In-and-Out",
		"version"=>"1.0",
		"author"=>"Gary Hartzell", 
		"category"=>"Stores",
		"download"=>"",
	"settings"=>array(
		"In-and-Out - General Settings,title",
		"storename"=>"Name of the store:,text|The In-and-Out",
		"storedesc"=>"Store description:,text|A convenience store.",
		"clerkname"=>"Clerk's name:,text|Hubbabubba",
		"clerkdesc"=>"Clerk description:,text|an excitable Neptunian"
		),
	);
	return $info;
	}

function inout_install(){
	module_addhook("village");

	return true;
}

function inout_uninstall(){
	return true;
}

function inout_dohook($hookname, $args){
global $session;
switch($hookname){
	case "village":
		tlschema($args['schemas']['fightnav']);
		addnav($args['fightnav']);
		tlschema();
		addnav("The In-and-Out","runmodule.php?module=inout&store=s1");
	break;
	}
	return $args;
}

function inout_run() {
	global $session;
	$texts=array();
	$storename = get_module_setting("storename");
	page_header($storename);
//	rawoutput("<center><h2>" . $storename . "</h2></center><br><br>");
output("`A%s`A`n`n", $storename);
output("%s", $shoptext);

modulehook("store_inout_items", $texts);

addnav("Leave");
//require_once("lib/egw.php");
//egw_nav();
require_once("lib/villagenav.php");
villagenav();


page_footer();
}
?>
