<?php

//Include in case "dropall".

addnav("Return to inventory","runmodule.php?module=inv");
require_once("lib/egw.php");
egw_nav();

$weight=get_module_setting("weight");
$how_many = get_module_pref("how_many");
$total_weight = $weight * $how_many;

increment_module_pref('weight',-$total_weight,'inv');
increment_module_pref('items',-$how_many,'inv');
set_module_pref('how_many',0);
output("You have dropped all of this item.");

?>
