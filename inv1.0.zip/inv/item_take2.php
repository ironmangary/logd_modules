<?php

//Include in item_*.php in case "take2".

increment_module_pref("how_many",+1);
increment_module_pref("uses_left",+get_module_setting("uses"));
increment_module_pref('items',+1,'inv');
increment_module_pref('weight',+get_module_setting("weight"),'inv');

require_once("lib/egw.php");
egw_nav();

?>
