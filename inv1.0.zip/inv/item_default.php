<?php

//Include in item_*.php in case "".

output("%s`n`n",get_module_setting("description"));
$weight = get_module_setting("weight");
$howmany = get_module_pref("how_many");
output("This item weighs %s ounces.`n",$weight);
output("You currently own %s of this item, for a total of %s ounces.",$howmany,$howmany * $weight);

addnav("Use Item",$from."&op=use");
addnav("Drop 1",$from."&op=drop1");
if ($howmany > 1) {addnav("Drop All",$from."&op=dropall");}
addnav("Return to inventory", "runmodule.php?module=inv");
require_once("lib/egw.php");
egw_nav();

?>
