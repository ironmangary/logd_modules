<?php

//Include in case "drop1".

addnav("Return to item", $from);
addnav("Return to inventory","runmodule.php?module=inv");
require_once("lib/egw.php");
egw_nav();

$weight=get_module_setting("weight");
increment_module_pref('weight',-$weight,'inv');
increment_module_pref('items',-1,'inv');
increment_module_pref('how_many',-1);
output("You have dropped one %s.",get_module_setting("name"));

?>
