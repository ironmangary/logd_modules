<?php

//Include in item_*.php in case "take".

output("%s`n`n",get_module_setting("description"));
$weight = get_module_setting("weight");
$howmany = get_module_pref("how_many");
$gold = get_module_setting("cost_gold");
$gems = get_module_setting("cost_gems");

output("Weight: %s ounces.`n",$weight);
output("You currently own %s of this item, for a total of %s ounces.",$howmany,$howmany * $weight);

$new_weight = get_module_pref('weight','inv') + $weight;
$max_weight = get_module_setting('max_weight','inv');
$max_items = get_module_setting('max_amount','inv');

if ($max_weight > 0 && $new_weight > $max_weight) {
	output("`n`nYou have no room in your backpack for this item at the moment.");
} elseif ($max_items > 0 && get_module_pref('items','inv') >= $max_items) {
	output("`n`nYou have no room in your backpack for this item at the moment.");
} else {
addnav("Take Item",$from."&op=take2");
}
require_once("lib/egw.php");
egw_nav();

?>
