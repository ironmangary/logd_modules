<?php

//Include in item_*.php in case "buy2".
//Confirm/finalize purchase of item

$gold = get_module_setting("cost_gold");
$gems = get_module_setting("cost_gems");
$session['user']['gold'] -= $gold;
$session['user']['gems'] -= $gems;
increment_module_pref("how_many",+1);
increment_module_pref("uses_left",+get_module_setting("uses"));
increment_module_pref('items',+1,'inv');
increment_module_pref('weight',+get_module_setting("weight"),'inv');

require_once("lib/egw.php");
egw_nav();

?>
