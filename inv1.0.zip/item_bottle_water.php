<?php
require_once("lib/http.php");

/*
Item: Bottle of water
for EGW Inventory System
Version 1.0 (2020-07-14)
by Gary M. Hartzell
*/

function item_bottle_water_getmoduleinfo(){
	$info = array(
		"name"=>"Item: Bottle of Water",
		"version"=>"1.0",
		"author"=>"Gary Hartzell", 
		"override_forced_nav"=>true,
		"category"=>"Items: Food",
		"download"=>"",
	"settings"=>array(
		"Item - General Settings,title",
		"name"=>"Item name:,text|Bottle of water",
		"category"=>"Category:,text|Food",
		"weight"=>"Weight (ounces):,int|8",
		"description"=>"Description:,text|This is an 8 oz. bottle of water.  Drink it when you're thirsty.",
		"cost_gold"=>"Cost (in gold):,int|50",
		"uses"=>"How many times can this item be used (0=unlimited)?,int|1"
),
	"prefs"=>array(
		"how_many"=>"How many of this item does user have?,int|0",
		"uses_left"=>"Ho many uses are left?,int|0"
	),
);
	return $info;
	}

function item_bottle_water_install(){
	module_addhook("inv_list");
	module_addhook("store_inout_items");
	return true;
}

function item_bottle_water_uninstall(){
	return true;
}

function item_bottle_water_dohook($hookname, $args){
	global $session;
	
switch($hookname){
		case "inv_list":
			$name = get_module_setting("name");
			$how_many=get_module_pref("how_many");
			if ($how_many > 0) {
				output("%s (%s)`n",$name,$how_many);
				addnav("Items");
				addnav(array("%s", $name), "runmodule.php?module=item_bottle_water");
			}
		break;
		case "store_inout_items":
			if (get_module_pref("where", "travel") == "village.php") {
				$name = get_module_setting("name");
				$category = get_module_setting("category");
				addnav($category);
				addnav(array("%s",$name),"runmodule.php?module=item_bottle_water&op=buy1");
			}
		break;
	}
	return $args;
}

function item_bottle_water_run() {

	global $session;
	$name = get_module_setting("name");
	page_header($name);
	rawoutput("<center><h2>");
	output("%s",$name);
	rawoutput("</h2></center><br>");

$from='runmodule.php?module=item_bottle_water';
	$op = httpget('op');
	switch ($op) {
		case "":
			include_once("modules/inv/item_default.php");
		break;
		case "use":
			include_once("modules/inv/item_use.php");

			increment_module_pref('stamina',1,'stamina');
			output("You down the bottle of water and feel a little better.`n`nYou gain 1 stamina.");
		break;
		case "drop1":
			include_once("modules/inv/item_drop1.php");
		break;
		case "dropall":
			include_once("modules/inv/item_dropall.php");
		break;
	}

	page_footer();
}
?>

