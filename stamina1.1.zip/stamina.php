<?php
require_once("lib/http.php");

/*
EarthGoneWrong.com Stamina System
by Gary Hartzell
v1.1 Beta

The basic concept is to replace turns/forest fights with stamina using this module.

I'm also adding support for fullness and intoxication, which go hand and hand with the concept of this stamina system.
Fullness will prevent a player from ordering more food/drink once they hit the "fullness" limit, which I'm setting at 15 points to start.
These fullness points can allow a player a normal diet of 3 meals plus something to drink (meals are 3-4 pts and drinks are 1-2 pts).

v1.1 (10/21/23)
- Increased stamina by 5x to allow for more flexibility

*/

function stamina_getmoduleinfo(){
	$info = array(
		"name"=>"EGW Stamina System",
		"version"=>"1.1",
		"author"=>"Gary Hartzell", 
		"category"=>"EGW Systems",
		"download"=>"",
		"settings"=>array(
		"base_stamina"=>"Base stamina setting,int|100",
		"fight_stamina"=>"How much stamina does a fight take?,int|5",
		"level_stamina"=>"How much stamina should a player gain per level?,int|10",
		"max_fullness"=>"Maximum fullness points,int",
		"max_intoxication"=>"Maximum intoxication points,int",
		),
		"prefs"=>array(
		"bonus_stamina"=>"User's Bonus Stamina,int|0",
		"stamina"=>"User's current remaining stamina,int",
		"fullness"=>"User's fullness,int|0",
		"intoxication"=>"User's intoxication,int|0",
		),
		);
	return $info;
	}

function stamina_install(){
	module_addhook("newday");
	module_addhook("autolevel");
	module_addhook("battle-victory");
	module_addhook("battle");
	module_addhook("charstats");
	module_addhook("dragonkill");
	module_addhook("everyhit");
	module_addhook("forestsearch");
	return true;
}

function stamina_uninstall(){
	return true;
}

function stamina_dohook($hookname, $args){
	global $session;
	
switch($hookname){	
	case "newday":
		$stamina = get_module_setting("base_stamina") + get_module_pref("bonus_stamina");
		$hp = $session['user']['hitpoints'];
		
		if (get_module_pref("current_resurrection", "afterlife") == 1) {
			//Take away hitpoints and stamina from resurrected players, tied into afterlife.php
			$stamina *= (100 - get_module_setting("stamina_loss", "afterlife")) * .01;
			$session['user']['hitpoints'] *= (100 - get_module_setting("hp_loss", "afterlife")) * .01;
		
			output("As you open your eyes, you realize that you are somehow alive.  You recall dying, but you're back again.  You don't know whether to laugh or cry.`n`n");
			output("Your health and stamina suck.  You'll need to do something about that.");
			set_module_pref("current_resurrection", 0, "afterlife");
		} else {
			output("`nAfter a good night's sleep, you wake up refreshed.");
			output("Your stamina has been restored to %s!  ",$stamina);
			output("Your health has been restored to %s!",$session['user']['hitpoints']);
		}

		set_module_pref("stamina", $stamina);
		set_module_pref("fullness",0);
		set_module_pref("intoxication",0);
		break;

	case "autolevel":
		$bonus = get_module_pref("bonus_stamina");
		$bonus += get_module_setting("level_stamina");
		set_module_pref("bonus_stamina", $bonus);
		increment_module_pref("stamina", +get_module_setting("bonus_stamina"));
		output("You gain %s stamina points!", get_module_setting("level_stamina"));
		break;
	case "battle-victory":
		$newstamina = get_module_pref("stamina") - get_module_setting("fight_stamina");
		set_module_pref("stamina",$newstamina);
		$intox=get_module_pref('intoxication');
		if ($intox > 0)
			set_module_pref('intoxication', $intox - 1);
		break;
	case "battle":
		if (get_module_pref('intoxication') >= get_module_setting('max_intoxication')) {
			$buff = array (
				"name"=>"Drunken Stooper",
				"rounds"=>10,
				"atkmod"=>0.7,
				"defmod"=>0.8,
				"roundmsg"=>"You're drunk!"
				);
			apply_buff("drunk", $buff);
			}
		break;
	case "charstats":
		$base=get_module_setting("base_stamina");
		$bonus=get_module_pref("bonus_stamina");
		$total = $base + $bonus;
		setcharstat("Character Info", "Stamina", get_module_pref("stamina")."/".$total);
		break;
	case "dragonkill":
		$new_stamina = get_module_pref("bonus_stamina") - 28;
		set_module_pref("bonus_stamina", $new_stamina);
	break; 
	case "everyhit":
		$total = get_module_setting("base_stamina") + get_module_pref("bonus_stamina");
		if (get_module_pref("stamina") > $total) {
			set_module_pref("stamina", $total);
		} elseif (get_module_pref("stamina") < 0) {
			set_module_pref("stamina", 0);
		}
		break;
	case "forestsearch":
		if (get_module_pref("stamina") <= 0) {
			page_header("The Coliseum");
			rawoutput("<center><h2>The Coliseum</h2></center><br>");
			output("You are too tired.  Get some food or some sleep.");
			villagenav();
			}
		break;
	}
	return $args;
}

function stamina_run() {
}
?>
